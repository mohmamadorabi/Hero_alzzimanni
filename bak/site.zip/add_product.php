<?php
require_once 'config.php';
include 'navbar.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // جلب البيانات من النموذج
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $category_id = intval($_POST['category']);
    $price = floatval($_POST['price']);
    $image = $_FILES['image'];

    // التحقق من صحة البيانات
    if (empty($name) || empty($description) || empty($category_id) || empty($price) || empty($image['name'])) {
        $message = "يرجى ملء جميع الحقول المطلوبة.";
    } else {
        // التحقق من نوع وحجم الملف المرفوع
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($image['type'], $allowed_types)) {
            $message = "نوع الملف غير مدعوم. يرجى رفع صورة بصيغة JPEG أو PNG أو GIF.";
        } elseif ($image['size'] > 2 * 1024 * 1024) { // الحد الأقصى 2 ميجابايت
            $message = "حجم الملف كبير جدًا. الحد الأقصى للحجم هو 2 ميجابايت.";
        } else {
            // رفع الصورة
            $upload_dir = 'uploads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            $image_name = time() . '_' . basename($image['name']);
            $image_path = $upload_dir . $image_name;
            if (move_uploaded_file($image['tmp_name'], $image_path)) {
                // إدخال المنتج في قاعدة البيانات
                $stmt = $conn->prepare("INSERT INTO products1 (name, description, category_id, price, image) VALUES (?, ?, ?, ?, ?)");
                if ($stmt) {
                    $stmt->bind_param("ssids", $name, $description, $category_id, $price, $image_name);
                    if ($stmt->execute()) {
                        $message = "تم إضافة المنتج بنجاح.";
                    } else {
                        $message = "حدث خطأ أثناء إضافة المنتج: " . htmlspecialchars($stmt->error);
                    }
                    $stmt->close();
                } else {
                    $message = "فشل في تحضير الاستعلام: " . htmlspecialchars($conn->error);
                }
            } else {
                $message = "حدث خطأ أثناء رفع الصورة.";
            }
        }
    }
}

// جلب الفئات من قاعدة البيانات لعرضها في النموذج
$categories = $conn->query("SELECT id, name FROM categories");
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة منتج | AZORPUB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">إضافة منتج</h1>
        <?php if (!empty($message)): ?>
            <div class="alert alert-info text-center">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <form action="add_product.php" method="POST" enctype="multipart/form-data" class="card shadow p-4">
                    <div class="mb-3">
                        <label for="name" class="form-label">اسم المنتج</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">الوصف</label>
                        <textarea class="form-control" id="description" name="description" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="category" class="form-label">الفئة</label>
                        <select class="form-select" id="category" name="category" required>
                            <option value="" disabled selected>اختر فئة</option>
                            <?php while ($category = $categories->fetch_assoc()): ?>
                                <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="price" class="form-label">السعر</label>
                        <input type="number" class="form-control" id="price" name="price" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">الصورة</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">إضافة المنتج</button>
                        <a href="dashboard.php" class="btn btn-secondary">إلغاء</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// إغلاق الاتصال بقاعدة البيانات
$conn->close();
?>
