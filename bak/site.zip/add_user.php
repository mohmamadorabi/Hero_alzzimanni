<?php
$conn = new mysqli('sql113.infinityfree.com', 'if0_37965291', '2DDOcIPdiD', 'if0_37965291_my_website');

// التحقق من الاتصال
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// بيانات المستخدم الجديد
$username = "admin"; // اسم المستخدم
$password = "123456"; // كلمة المرور
$hashed_password = password_hash($password, PASSWORD_DEFAULT); // تشفير كلمة المرور

// إدخال المستخدم
$stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $username, $hashed_password);
$stmt->execute();

echo "User added successfully!";
$conn->close();
?>
