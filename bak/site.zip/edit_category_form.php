<?php
session_start();
include 'navbar.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// تفاصيل الاتصال بقاعدة البيانات
$conn = new mysqli('sql113.infinityfree.com', 'if0_37965291', '2DDOcIPdiD', 'if0_37965291_my_website');

// التحقق من الاتصال
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// جلب بيانات الفئة بناءً على ID
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM categories WHERE id = $id");
    $category = $result->fetch_assoc();
    if (!$category) {
        header("Location: edit_category.php");
        exit();
    }
} else {
    header("Location: edit_category.php");
    exit();
}

// تحديث بيانات الفئة
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $stmt = $conn->prepare("UPDATE categories SET name = ? WHERE id = ?");
    $stmt->bind_param("si", $name, $id);
    $stmt->execute();
    header("Location: edit_category.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Category | AZORPUB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Edit Category</h1>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form action="" method="POST" class="card shadow p-4">
                    <div class="mb-3">
                        <label for="name" class="form-label">Category Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($category['name']) ?>" required>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Update Category</button>
                        <a href="edit_category.php" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
