<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'config.php';

// التحقق من أن الطلب من نوع POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'];
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $category_id = intval($_POST['category']);
    $price = floatval($_POST['price']);
    $upload_dir = 'uploads/';
    $message = '';

    // التحقق من صحة البيانات
    if (empty($name) || empty($description) || empty($category_id) || empty($price)) {
        echo "جميع الحقول مطلوبة.";
        exit();
    }

    // تحديث المنتج
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image = $_FILES['image'];
        $file_extension = strtolower(pathinfo($image['name'], PATHINFO_EXTENSION));
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

        if (!in_array($file_extension, $allowed_types)) {
            echo "نوع الملف غير مدعوم. يرجى رفع صورة بصيغة JPG أو PNG.";
            exit();
        }

        $image_name = uniqid('product_', true) . '.' . $file_extension;
        $image_path = $upload_dir . $image_name;

        if (move_uploaded_file($image['tmp_name'], $image_path)) {
            // حذف الصورة القديمة
            $stmt_old = $conn->prepare("SELECT image FROM products1 WHERE id = ?");
            $stmt_old->bind_param("i", $product_id);
            $stmt_old->execute();
            $result_old = $stmt_old->get_result();
            if ($old_image = $result_old->fetch_assoc()) {
                $old_image_path = $upload_dir . $old_image['image'];
                if (file_exists($old_image_path)) {
                    unlink($old_image_path);
                }
            }
            $stmt_old->close();

            // تحديث المنتج مع الصورة الجديدة
            $stmt = $conn->prepare("UPDATE products1 SET name = ?, description = ?, category_id = ?, price = ?, image = ? WHERE id = ?");
            $stmt->bind_param("ssidsi", $name, $description, $category_id, $price, $image_name, $product_id);
        } else {
            echo "حدث خطأ أثناء رفع الصورة.";
            exit();
        }
    } else {
        // تحديث المنتج بدون تغيير الصورة
        $stmt = $conn->prepare("UPDATE products1 SET name = ?, description = ?, category_id = ?, price = ? WHERE id = ?");
        $stmt->bind_param("sssdi", $name, $description, $category_id, $price, $product_id);
    }

    // تنفيذ الاستعلام
    if ($stmt->execute()) {
        $_SESSION['message'] = "تم تحديث المنتج بنجاح.";
        header("Location: edit_product.php");
        exit();
    } else {
        echo "حدث خطأ أثناء تحديث المنتج: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "طلب غير صالح.";
}

$conn->close();
?>
