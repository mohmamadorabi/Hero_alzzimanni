<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// استدعاء ملف الإعدادات
require_once 'config.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // جلب البيانات من النموذج
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $category_id = intval($_POST['category_id']); // استخدام category_id
    $price = floatval($_POST['price']);
    $image = $_FILES['image'];

    // التحقق من صحة البيانات
    if (empty($name) || empty($description) || empty($category_id) || empty($price) || empty($image['name'])) {
        die("يرجى ملء جميع الحقول المطلوبة.");
    }

    // التحقق من نوع وحجم الملف المرفوع
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    if (!in_array($image['type'], $allowed_types)) {
        die("نوع الملف غير مدعوم. يرجى رفع صورة بصيغة JPEG أو PNG أو GIF.");
    }
    if ($image['size'] > 2 * 1024 * 1024) { // 2 ميجابايت
        die("حجم الملف كبير جدًا. الحد الأقصى للحجم هو 2 ميجابايت.");
    }

    // رفع الصورة
    $upload_dir = 'uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    $image_path = $upload_dir . basename($image['name']);
    if (move_uploaded_file($image['tmp_name'], $image_path)) {
        // إدخال المنتج في قاعدة البيانات
        $stmt = $conn->prepare("INSERT INTO products1 (name, description, category_id, price, image) VALUES (?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("ssids", $name, $description, $category_id, $price, $image_path);
            if ($stmt->execute()) {
                // إعادة التوجيه إلى لوحة التحكم
                header("Location: dashboard.php");
                exit();
            } else {
                echo "حدث خطأ أثناء إضافة المنتج: " . htmlspecialchars($stmt->error);
            }
            $stmt->close();
        } else {
            echo "فشل في تحضير الاستعلام: " . htmlspecialchars($conn->error);
        }
    } else {
        echo "حدث خطأ أثناء رفع الصورة.";
    }
}

// إغلاق الاتصال بقاعدة البيانات
$conn->close();
?>
