<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config.php';
include 'navbar.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// التحقق من وجود معرف المنتج في الرابط
if (!isset($_GET['id'])) {
    header("Location: edit_product.php");
    exit();
}

$product_id = intval($_GET['id']);

// جلب بيانات المنتج من قاعدة البيانات
$stmt = $conn->prepare("SELECT * FROM products1 WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();
$stmt->close();

if (!$product) {
    header("Location: edit_product.php");
    exit();
}

// جلب الفئات من قاعدة البيانات
$categories = $conn->query("SELECT id, name FROM categories");
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل منتج | AZORPUB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">تعديل منتج</h1>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <form action="process_edit_product.php?id=<?= $product_id ?>" method="POST" enctype="multipart/form-data" class="card shadow p-4">
                <input type="hidden" name="product_id" value="<?= $product_id ?>">    
                <div class="mb-3">
                        <label for="name" class="form-label">اسم المنتج</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">الوصف</label>
                        <textarea class="form-control" id="description" name="description" required><?= htmlspecialchars($product['description']) ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="category" class="form-label">الفئة</label>
                        <select class="form-select" id="category" name="category" required>
                            <option value="" disabled>اختر فئة</option>
                            <?php while ($category = $categories->fetch_assoc()): ?>
                                <option value="<?= $category['id'] ?>" <?= $product['category_id'] == $category['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($category['name']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="price" class="form-label">السعر</label>
                        <input type="number" class="form-control" id="price" name="price" value="<?= htmlspecialchars($product['price']) ?>" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label for="current_image" class="form-label">الصورة الحالية</label><br>
                        <img src="uploads/<?= htmlspecialchars($product['image']) ?>" alt="صورة المنتج" class="img-fluid mb-3" style="max-height: 200px;">
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">تغيير الصورة (اختياري)</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*">
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">تحديث المنتج</button>
                        <a href="edit_product.php" class="btn btn-secondary">إلغاء</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
