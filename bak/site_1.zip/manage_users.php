<?php
require_once 'config.php';
require_once 'auth.php';
include 'navbar.php';
checkRole('admin'); // السماح فقط للمستخدمين من نوع Admin

$message = ''; // لتخزين الرسائل

// إضافة مستخدم جديد
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role = $_POST['role'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    if (!empty($username) && !empty($password)) {
        $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $hashed_password, $role);
        if ($stmt->execute()) {
            $message = "تمت إضافة المستخدم بنجاح.";
        } else {
            $message = "حدث خطأ أثناء إضافة المستخدم.";
        }
        $stmt->close();
    } else {
        $message = "يرجى إدخال اسم المستخدم وكلمة المرور.";
    }
}

// تعديل مستخدم
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_user'])) {
    $user_id = intval($_POST['user_id']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role = $_POST['role'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    if (!empty($username) && !empty($password)) {
        $stmt = $conn->prepare("UPDATE users SET username = ?, password = ?, role = ? WHERE id = ?");
        $stmt->bind_param("sssi", $username, $hashed_password, $role, $user_id);
        if ($stmt->execute()) {
            $message = "تم تعديل المستخدم بنجاح.";
        } else {
            $message = "حدث خطأ أثناء تعديل المستخدم.";
        }
        $stmt->close();
    } else {
        $message = "يرجى إدخال اسم المستخدم وكلمة المرور.";
    }
}

// حذف مستخدم
if (isset($_GET['delete'])) {
    $user_id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $message = "تم حذف المستخدم بنجاح.";
    } else {
        $message = "حدث خطأ أثناء حذف المستخدم.";
    }
    $stmt->close();
}

// جلب جميع المستخدمين
$users = $conn->query("SELECT id, username, role FROM users");
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المستخدمين | AZORPUB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">إدارة المستخدمين</h1>
    <?php if (!empty($message)): ?>
        <div class="alert alert-info text-center"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <!-- نموذج إضافة مستخدم جديد -->
    <form action="manage_users.php" method="POST" class="mb-4">
        <div class="row">
            <div class="col-md-3">
                <input type="text" name="username" class="form-control" placeholder="اسم المستخدم" required>
            </div>
            <div class="col-md-3">
                <input type="password" name="password" class="form-control" placeholder="كلمة المرور" required>
            </div>
            <div class="col-md-3">
                <select name="role" class="form-select" required>
                    <option value="viewer">Viewer</option>
                    <option value="editor">Editor</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" name="add_user" class="btn btn-primary w-100">إضافة مستخدم</button>
            </div>
        </div>
    </form>

    <!-- جدول المستخدمين -->
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>#</th>
            <th>اسم المستخدم</th>
            <th>الدور</th>
            <th>إجراءات</th>
        </tr>
        </thead>
        <tbody>
        <?php while ($user = $users->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($user['id']) ?></td>
                <td>
                    <form action="manage_users.php" method="POST" class="d-flex">
                        <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                        <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" required>
                        <select name="role" class="form-select mx-2" required>
                            <option value="viewer" <?= $user['role'] === 'viewer' ? 'selected' : '' ?>>Viewer</option>
                            <option value="editor" <?= $user['role'] === 'editor' ? 'selected' : '' ?>>Editor</option>
                            <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                        </select>
                        <input type="password" name="password" class="form-control" placeholder="كلمة مرور جديدة" required>
                        <button type="submit" name="edit_user" class="btn btn-success btn-sm mx-2">تعديل</button>
                    </form>
                </td>
                <td><?= htmlspecialchars($user['role']) ?></td>
                <td>
                    <a href="manage_users.php?delete=<?= $user['id'] ?>" 
                       class="btn btn-danger btn-sm" 
                       onclick="return confirm('هل أنت متأكد من حذف هذا المستخدم؟');">حذف</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
