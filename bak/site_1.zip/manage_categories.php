<?php
require_once 'config.php';
include 'navbar.php';
require_once 'auth.php'; // التحقق من الجلسة

// التحقق من صلاحيات المستخدم
if ($_SESSION['role'] === 'viewer') {
    die("ليس لديك الصلاحيات لإدارة الفئات.");
}

// رسالة للتأكيد
$message = '';

// إضافة فئة جديدة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_category'])) {
    $category_name = trim($_POST['category_name']);
    if (!empty($category_name)) {
        $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->bind_param("s", $category_name);
        if ($stmt->execute()) {
            $message = "تمت إضافة الفئة بنجاح.";
        } else {
            $message = "حدث خطأ أثناء إضافة الفئة.";
        }
        $stmt->close();
    } else {
        $message = "يرجى إدخال اسم الفئة.";
    }
}

// تعديل فئة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_category'])) {
    $category_id = intval($_POST['category_id']);
    $category_name = trim($_POST['category_name']);
    if (!empty($category_name)) {
        $stmt = $conn->prepare("UPDATE categories SET name = ? WHERE id = ?");
        $stmt->bind_param("si", $category_name, $category_id);
        if ($stmt->execute()) {
            $message = "تم تعديل الفئة بنجاح.";
        } else {
            $message = "حدث خطأ أثناء تعديل الفئة.";
        }
        $stmt->close();
    } else {
        $message = "يرجى إدخال اسم الفئة.";
    }
}

// حذف فئة
if (isset($_GET['delete'])) {
    $category_id = intval($_GET['delete']);

    // التحقق من المنتجات المرتبطة بالفئة
    $stmt = $conn->prepare("SELECT COUNT(*) FROM products1 WHERE category_id = ?");
    $stmt->bind_param("i", $category_id);
    $stmt->execute();
    $stmt->bind_result($product_count);
    $stmt->fetch();
    $stmt->close();

    if ($product_count > 0) {
        $message = "لا يمكن حذف الفئة لأنها تحتوي على $product_count منتج/منتجات.";
    } else {
        $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->bind_param("i", $category_id);
        if ($stmt->execute()) {
            $message = "تم حذف الفئة بنجاح.";
        } else {
            $message = "حدث خطأ أثناء حذف الفئة.";
        }
        $stmt->close();
    }
}

// جلب جميع الفئات مع عدد المنتجات المرتبطة بكل فئة
$query = "
    SELECT categories.id, categories.name,
           (SELECT COUNT(*) FROM products1 WHERE products1.category_id = categories.id) AS product_count 
    FROM categories
";
$categories = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الفئات | AZORPUB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">إدارة الفئات</h1>
    <?php if ($message): ?>
        <div class="alert alert-info text-center"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <!-- نموذج إضافة فئة جديدة -->
    <form action="manage_categories.php" method="POST" class="mb-4">
        <div class="row">
            <div class="col-md-8">
                <input type="text" name="category_name" class="form-control" placeholder="اسم الفئة الجديدة" required>
            </div>
            <div class="col-md-4">
                <button type="submit" name="add_category" class="btn btn-primary w-100">إضافة فئة</button>
            </div>
        </div>
    </form>

    <!-- جدول الفئات -->
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>#</th>
            <th>اسم الفئة</th>
            <th>عدد المنتجات</th>
            <th>إجراءات</th>
        </tr>
        </thead>
        <tbody>
        <?php while ($category = $categories->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($category['id']) ?></td>
                <td>
                    <form action="manage_categories.php" method="POST" class="d-flex">
                        <input type="hidden" name="category_id" value="<?= $category['id'] ?>">
                        <input type="text" name="category_name" class="form-control" value="<?= htmlspecialchars($category['name']) ?>" required>
                        <button type="submit" name="edit_category" class="btn btn-success btn-sm ms-2">تعديل</button>
                    </form>
                </td>
                <td><?= $category['product_count'] ?></td>
                <td>
                    <a href="manage_categories.php?delete=<?= $category['id'] ?>" 
                       class="btn btn-danger btn-sm" 
                       onclick="return confirm('هل أنت متأكد من حذف هذه الفئة؟');">حذف</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// إغلاق الاتصال بقاعدة البيانات
$conn->close();
?>
