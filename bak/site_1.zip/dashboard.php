<?php
require_once 'config.php';
require_once 'auth.php';

// Fetch categories and their product count
$categories_query = "
    SELECT 
        categories.id AS category_id,
        categories.name AS category_name,
        COUNT(products1.id) AS product_count
    FROM 
        categories
    LEFT JOIN 
        products1 
    ON 
        categories.id = products1.category_id
    GROUP BY 
        categories.id, categories.name
";
$categories_result = $conn->query($categories_query);

// Fetch products grouped by category
$products_query = "
    SELECT 
        products1.id AS product_id,
        products1.name AS product_name,
        products1.quantity,
        products1.price,
        categories.id AS category_id
    FROM 
        products1
    LEFT JOIN 
        categories 
    ON 
        products1.category_id = categories.id
    ORDER BY 
        categories.id, products1.name
";
$products_result = $conn->query($products_query);

// Group products by category
$products_by_category = [];
while ($row = $products_result->fetch_assoc()) {
    $products_by_category[$row['category_id']][] = $row;
}

// Fetch products with low or zero quantity for sidebar notifications
$notifications_query = "
    SELECT 
        products1.id, 
        products1.name AS product_name, 
        products1.quantity, 
        categories.name AS category_name 
    FROM 
        products1
    LEFT JOIN 
        categories 
    ON 
        products1.category_id = categories.id
    WHERE 
        products1.quantity <= 1
    ORDER BY 
        products1.quantity ASC
";
$notifications_result = $conn->query($notifications_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        /* Sidebar styles */
        .sidebar {
            position: fixed;
            top: 0;
            left: -300px;
            width: 300px;
            height: 100%;
            background-color: #f8f9fa;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            transition: left 0.3s ease;
            z-index: 1050;
            padding: 20px;
        }
        .sidebar.open {
            left: 0;
        }
        .sidebar-header {
            font-size: 1.25rem;
            font-weight: bold;
            margin-bottom: 1rem;
        }
        .notification-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #ddd;
        }
        .notification-item:last-child {
            border-bottom: none;
        }
        .notification-actions {
            display: flex;
            gap: 10px;
        }
        .notification-actions i {
            cursor: pointer;
            font-size: 1.2rem;
        }
        .notification-actions i:hover {
            color: #007bff;
        }
        .toggle-sidebar {
            position: absolute;
            top: 10px;
            right: -40px;
            width: 40px;
            height: 40px;
            background-color: #007bff;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 5px;
            cursor: pointer;
        }
        .toggle-sidebar:hover {
            background-color: #0056b3;
        }

        /* Category and product list styles */
        .category-list {
            margin: 20px 0;
        }
        .category-item {
            cursor: pointer;
            font-weight: bold;
            padding: 10px;
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            margin-bottom: 5px;
            border-radius: 5px;
        }
        .category-item:hover {
            background-color: #e9ecef;
        }
        .product-list {
            margin-left: 20px;
            display: none;
        }
        .product-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 5px 0;
            border-bottom: 1px solid #ddd;
        }
        .product-item:last-child {
            border-bottom: none;
        }
        .product-actions {
            display: flex;
            gap: 10px;
        }
        .product-actions i {
            cursor: pointer;
            font-size: 1.2rem;
        }
        .product-actions i:hover {
            color: #007bff;
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<!-- Sidebar -->
<div id="sidebar" class="sidebar">
    <div class="sidebar-header">
        Notifications
        <div class="toggle-sidebar" onclick="toggleSidebar()">&#x25C0;</div>
    </div>
    <div id="notificationList">
        <?php while ($notification = $notifications_result->fetch_assoc()): ?>
            <div class="notification-item">
                <div>
                    <strong><?= htmlspecialchars($notification['product_name']) ?></strong><br>
                    <small>Category: <?= htmlspecialchars($notification['category_name'] ?? 'Uncategorized') ?></small><br>
                    <small>Quantity: 
                        <span class="<?= $notification['quantity'] == 0 ? 'text-danger' : 'text-warning' ?>">
                            <?= htmlspecialchars($notification['quantity']) ?>
                        </span>
                    </small>
                </div>
                <div class="notification-actions">
                    <a href="edit_product_form.php?id=<?= $notification['id'] ?>">
                        <i class="fas fa-edit text-success"></i>
                    </a>
                    <i class="fas fa-trash text-danger" onclick="deleteProduct(<?= $notification['id'] ?>)"></i>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<div class="container mt-5">
    <h1 class="text-center">Dashboard</h1>

    <!-- Categories and Products -->
    <h2 class="text-center my-4">Categories and Products</h2>
    <div class="category-list">
        <?php while ($category = $categories_result->fetch_assoc()): ?>
            <div class="category-item" data-category-id="<?= $category['category_id'] ?>">
                <?= htmlspecialchars($category['category_name']) ?> (<?= $category['product_count'] ?>)
                <span class="float-end">&#x25BC;</span>
            </div>
            <div class="product-list" id="products-<?= $category['category_id'] ?>" style="display: none;">
                <?php if (!empty($products_by_category[$category['category_id']])): ?>
                    <?php foreach ($products_by_category[$category['category_id']] as $product): ?>
                        <div class="product-item">
                            <span><?= htmlspecialchars($product['product_name']) ?></span>
                            <span>$<?= htmlspecialchars($product['price']) ?></span>
                            <span>Qty: <?= htmlspecialchars($product['quantity']) ?></span>
                            <div class="product-actions">
                                <a href="edit_product_form.php?id=<?= $product['product_id'] ?>">
                                    <i class="fas fa-edit text-success"></i>
                                </a>
                                <i class="fas fa-trash text-danger" onclick="deleteProduct(<?= $product['product_id'] ?>)"></i>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted">No products available.</p>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<script>
    function toggleSidebar() {
        const sidebar = document.getElementById("sidebar");
        sidebar.classList.toggle("open");
    }

    function deleteProduct(productId) {
        if (confirm("Are you sure you want to delete this product?")) {
            fetch(`delete_product.php?id=${productId}`, { method: 'POST' })
                .then(response => response.text())
                .then(data => {
                    alert(data);
                    location.reload();
                })
                .catch(error => console.error('Error:', error));
        }
    }

    // Toggle product list visibility
    document.querySelectorAll('.category-item').forEach(item => {
        item.addEventListener('click', () => {
            const categoryId = item.getAttribute('data-category-id');
            const productList = document.getElementById(`products-${categoryId}`);
            if (productList.style.display === 'none' || !productList.style.display) {
                productList.style.display = 'block';
                item.querySelector('span').textContent = '▲';
            } else {
                productList.style.display = 'none';
                item.querySelector('span').textContent = '▼';
            }
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
