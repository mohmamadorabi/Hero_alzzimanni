<?php
require_once 'auth.php';
if (!isset($_SESSION['role'])) {
    $_SESSION['role'] = 'viewer'; // تعيين دور افتراضي
}
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">AZORPUB</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <!-- رابط لوحة التحكم -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>" href="dashboard.php">Dashboard</a>
                </li>

                <!-- روابط Admin و Editor -->
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'editor'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'add_product.php' ? 'active' : '' ?>" href="add_product.php">Add Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'edit_product.php' ? 'active' : '' ?>" href="edit_product.php">Edit Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'manage_categories.php' ? 'active' : '' ?>" href="manage_categories.php">Manage Categories</a>
                    </li>
                <?php endif; ?>

                <!-- روابط Admin فقط -->
                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'manage_users.php' ? 'active' : '' ?>" href="manage_users.php">Manage Users</a>
                    </li>
                <?php endif; ?>

                <!-- رابط تسجيل الخروج -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'logout.php' ? 'active' : '' ?>" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
