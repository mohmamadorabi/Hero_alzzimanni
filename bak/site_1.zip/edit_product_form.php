<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config.php';
include 'navbar.php';

// التحقق من تسجيل الدخول
require_once 'auth.php'; // التحقق من الجلسة

// التحقق من وجود معرف المنتج في الرابط
if (!isset($_GET['id'])) {
    header("Location: edit_product.php");
    exit();
}

$product_id = intval($_GET['id']);

// جلب بيانات المنتج من قاعدة البيانات
$stmt = $conn->prepare("SELECT * FROM products1 WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();
$stmt->close();

if (!$product) {
    echo "<div class='container mt-5'><div class='alert alert-danger'>Product not found.</div></div>";
    exit();
}

// جلب الفئات من قاعدة البيانات
$categories = $conn->query("SELECT id, name FROM categories");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product | AZORPUB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Edit Product</h1>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <form action="process_product.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="product_id" value="<?= $product_id; ?>">
                    
                    <div class="mb-3">
                        <label for="name" class="form-label">Product Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($product['name']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" required><?= htmlspecialchars($product['description']); ?></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="category_id" class="form-label">Category</label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <?php
                            while ($category = $categories->fetch_assoc()) {
                                $selected = $category['id'] == $product['category_id'] ? "selected" : "";
                                echo "<option value='{$category['id']}' {$selected}>{$category['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="price" class="form-label">Price</label>
                        <input type="number" class="form-control" id="price" name="price" step="0.01" value="<?= $product['price']; ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" value="<?= $product['quantity']; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="image" class="form-label">Image</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*">
                        <?php if (!empty($product['image'])): ?>
                            <div class="mt-2">
                                <img src="uploads/<?= htmlspecialchars($product['image']); ?>" alt="Current Image" class="img-thumbnail" style="max-width: 150px;">
                                <p class="text-muted">Current Image: <?= htmlspecialchars($product['image']); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
