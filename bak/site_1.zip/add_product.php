<?php
require_once 'config.php';
include 'navbar.php';
require_once 'auth.php'; // التحقق من الجلسة

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // جلب البيانات من النموذج
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $category_id = intval($_POST['category_id']);
    $price = floatval($_POST['price']);
    $quantity = intval($_POST['quantity']);
    $image = $_FILES['image'];

    // التحقق من صحة البيانات
    if (empty($name) || empty($description) || empty($category_id) || empty($price) || empty($quantity) || empty($image['name'])) {
        $message = "Please fill in all required fields.";
    } else {
        // التحقق من نوع وحجم الملف المرفوع
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($image['type'], $allowed_types)) {
            $message = "Unsupported file type. Please upload a JPEG, PNG, or GIF image.";
        } elseif ($image['size'] > 2 * 1024 * 1024) { // الحد الأقصى 2 ميجابايت
            $message = "File size is too large. The maximum size is 2 MB.";
        } else {
            // رفع الصورة
            $upload_dir = 'uploads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            $image_name = time() . '_' . basename($image['name']);
            $image_path = $upload_dir . $image_name;
            if (move_uploaded_file($image['tmp_name'], $image_path)) {
                // إدخال المنتج في قاعدة البيانات
                $stmt = $conn->prepare("INSERT INTO products1 (name, description, category_id, price, quantity, image) VALUES (?, ?, ?, ?, ?, ?)");
                if ($stmt) {
                    $stmt->bind_param("ssidis", $name, $description, $category_id, $price, $quantity, $image_name);
                    if ($stmt->execute()) {
                        $message = "Product added successfully.";
                    } else {
                        $message = "Error adding product: " . htmlspecialchars($stmt->error);
                    }
                    $stmt->close();
                } else {
                    $message = "Failed to prepare query: " . htmlspecialchars($conn->error);
                }
            } else {
                $message = "Error uploading the image.";
            }
        }
    }
}

// جلب الفئات من قاعدة البيانات لعرضها في النموذج
$categories = $conn->query("SELECT id, name FROM categories");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product | AZORPUB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Add Product</h1>
        <?php if (!empty($message)): ?>
            <div class="alert alert-info text-center">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="name" class="form-label">Product Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="category_id" class="form-label">Category</label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <option value="" disabled selected>Select a Category</option>
                            <?php
                            while ($category = $categories->fetch_assoc()) {
                                echo "<option value='{$category['id']}'>{$category['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="price" class="form-label">Price</label>
                        <input type="number" class="form-control" id="price" name="price" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" required>
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">Image</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Product</button>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
