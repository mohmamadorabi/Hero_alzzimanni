<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// التحقق من الصلاحيات
function checkRole($required_role) {
    if ($_SESSION['role'] !== $required_role && $_SESSION['role'] !== 'admin') {
        die("ليس لديك الصلاحيات للوصول إلى هذه الصفحة.");
    }
}
?>
