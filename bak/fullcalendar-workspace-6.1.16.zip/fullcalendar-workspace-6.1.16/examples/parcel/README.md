
# FullCalendar Parcel 2 Example

Currently having trouble integrating FullCalendar + Parcel 2 because Parcel 2
unsuccessfully attempts to load babel within FullCalendar packages.

https://github.com/parcel-bundler/parcel/issues/4729
