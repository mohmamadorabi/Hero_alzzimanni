import React from 'react'

export default function() {
  return (
    <div>
      This is a placeholder. Click "toggle calendar" on the right.
    </div>
  )
}
