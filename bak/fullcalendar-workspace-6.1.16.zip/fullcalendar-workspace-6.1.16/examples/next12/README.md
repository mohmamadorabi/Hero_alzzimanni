
# FullCalendar Next.js 12 Example

FullCalendar works well with the React framework [Next.js](https://nextjs.org/)


## Installation

```bash
git clone https://github.com/fullcalendar/fullcalendar-examples.git
cd fullcalendar-examples/next12
npm install
```


## Build Commands

```
npm run dev # watch and rebuild while developing
npm run build # build for production
npm run start # run the production build
npm run lint # lint source files
```
