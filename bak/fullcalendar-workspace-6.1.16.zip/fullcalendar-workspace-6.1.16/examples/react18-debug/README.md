
# FullCalendar React 18 Example Project

For debugging these issues:

- https://github.com/fullcalendar/fullcalendar/issues/7071
- https://github.com/fullcalendar/fullcalendar/issues/7067
