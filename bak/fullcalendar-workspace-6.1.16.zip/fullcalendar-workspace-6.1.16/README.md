# FullCalendar Workspace

This monorepo encompasses all FullCalendar-related projects:

- [premium features](premium) - [custom license](premium/LICENSE.md)
- [standard features](https://github.com/fullcalendar/fullcalendar/tree/main) - MIT license
- connectors - MIT license
- examples - MIT license
