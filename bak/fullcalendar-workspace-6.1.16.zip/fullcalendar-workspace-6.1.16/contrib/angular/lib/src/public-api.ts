/*
 * Public API Surface of lib
 */

export * from './full-calendar.component';
export * from './full-calendar.module';
