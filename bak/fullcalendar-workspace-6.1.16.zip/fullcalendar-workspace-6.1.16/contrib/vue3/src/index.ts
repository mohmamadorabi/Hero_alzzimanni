import FullCalendarComponent from './FullCalendar.js'

export default FullCalendarComponent
