
export const OPTION_IS_COMPLEX: { [name: string]: boolean } = {
  headerToolbar: true,
  footerToolbar: true,
  events: true,
  eventSources: true,
  resources: true
}
